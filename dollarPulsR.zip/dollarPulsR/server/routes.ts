import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { db } from "@db";
import { products, orders, orderItems } from "@db/schema";
import { eq } from "drizzle-orm";

export function registerRoutes(app: Express): Server {
  setupAuth(app);

  app.get("/api/products", async (_req, res) => {
    const productList = await db.select().from(products);
    res.json(productList);
  });

  app.post("/api/products", async (req, res) => {
    if (!req.user?.isAdmin) {
      return res.status(403).send("Unauthorized");
    }

    const product = await db.insert(products).values(req.body).returning();
    res.json(product[0]);
  });

  app.get("/api/orders", async (req, res) => {
    if (!req.user) {
      return res.status(401).send("Not logged in");
    }

    const userOrders = await db
      .select()
      .from(orders)
      .where(eq(orders.userId, req.user.id));

    res.json(userOrders);
  });

  const httpServer = createServer(app);
  return httpServer;
}