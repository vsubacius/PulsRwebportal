import OpenAI from "openai";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function generateCodeResponse(prompt: string): Promise<{ response: string }> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        {
          role: "system",
          content: "You are Cosmic Coder, the most advanced AI coding assistant. You excel at providing detailed, accurate, and efficient coding solutions with explanations. Always format code blocks with appropriate syntax highlighting."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      temperature: 0.7,
      max_tokens: 2000
    });

    return { 
      response: response.choices[0].message.content || "No response generated"
    };
  } catch (error: any) {
    throw new Error(`Failed to generate AI response: ${error.message}`);
  }
}