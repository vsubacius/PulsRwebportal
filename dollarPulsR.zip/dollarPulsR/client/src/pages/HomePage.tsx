import { FC, useState, useEffect } from 'react';
import { useWallet, useConnection } from '@solana/wallet-adapter-react';
import { PublicKey } from '@solana/web3.js';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from '@/hooks/use-toast';
import { PaymentMethod, usePayment, MERCHANT_WALLET } from '@/lib/payment';
import { Loader2 } from 'lucide-react';
import { TransactionStatus } from '@/components/TransactionStatus';

interface GPT {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
}

const SAMPLE_GPTS: GPT[] = [
  {
    id: '1',
    name: 'SpaceTrader Pro',
    description: 'Advanced trading assistant specialized in crypto markets',
    price: .000000001, // Test amount
    image: '/gpt-trading.png'
  },
  {
    id: '2',
    name: 'Cosmic Coder',
    description: 'Expert programming assistant for blockchain development',
    price: .000000001, // Test amount
    image: '/gpt-coding.png'
  },
];

const HomePage: FC = () => {
  const { publicKey, connected } = useWallet();
  const { connection } = useConnection();
  const { handlePayment, getSolBalance, getPULSRBalance } = usePayment();
  const [pulsrBalance, setPulsrBalance] = useState<number>(0);
  const [solBalance, setSolBalance] = useState<number>(0);
  const [loading, setLoading] = useState(false);
  const [processingPayment, setProcessingPayment] = useState(false);
  const [selectedGPT, setSelectedGPT] = useState<GPT | null>(null);
  const { toast } = useToast();
  const [transactionStatus, setTransactionStatus] = useState<'preparing' | 'processing' | 'success' | 'error'>('preparing');
  const [transactionError, setTransactionError] = useState<string>();
  const [showTransaction, setShowTransaction] = useState(false);
  const [transactionDetails, setTransactionDetails] = useState({
    amount: 0,
    paymentMethod: PaymentMethod.SOL,
    toWallet: MERCHANT_WALLET.toString(),
    fromWallet: '',
    signature: '',
  });

  const fetchBalances = async () => {
    if (!publicKey || !connected) {
      setPulsrBalance(0);
      setSolBalance(0);
      return;
    }

    setLoading(true);
    try {
      const sol = await getSolBalance();
      setSolBalance(sol);
      const pulsr = await getPULSRBalance();
      setPulsrBalance(pulsr);
    } catch (error: any) {
      console.error('Error fetching balances:', error);
      toast({
        title: "Error",
        description: "Failed to fetch balances. Please try again.",
        variant: "destructive"
      });
    }
    setLoading(false);
  };

  useEffect(() => {
    if (connected) {
      fetchBalances();
    }
  }, [connected, publicKey]);

  const handlePurchase = async (gpt: GPT, paymentMethod: PaymentMethod) => {
    if (!connected) {
      toast({
        title: "Error",
        description: "Please connect your wallet first",
        variant: "destructive"
      });
      return;
    }

    setTransactionError(undefined);
    setTransactionStatus('preparing');
    setTransactionDetails({
      amount: paymentMethod === PaymentMethod.SOL ? gpt.price : 100,
      paymentMethod,
      toWallet: MERCHANT_WALLET.toString(),
      fromWallet: publicKey?.toString() || '',
      signature: '',
    });
    setShowTransaction(true);

    try {
      setTransactionStatus('processing');
      const price = paymentMethod === PaymentMethod.SOL ? gpt.price : 100;
      const signature = await handlePayment(price, paymentMethod);

      setTransactionDetails(prev => ({
        ...prev,
        signature,
      }));
      setTransactionStatus('success');

      toast({
        title: "Success",
        description: `Payment successful! Transaction: ${signature.slice(0, 8)}...`,
      });

      await fetchBalances();
    } catch (error: any) {
      setTransactionStatus('error');
      setTransactionError(error.message);
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  return (
    <div className="min-h-screen">
      <div className="container mx-auto px-4 py-12">
        <div className="flex flex-col items-center justify-center mb-16 space-y-4">
          <h1 className="text-6xl font-bold bg-gradient-to-r from-white via-blue-100 to-blue-200 bg-clip-text text-transparent text-center">
            PulsR GPT Vault
          </h1>
          <p className="text-xl text-blue-100/80 font-light max-w-2xl text-center">
            Access our exclusive collection of specialized GPT models powered by the future of AI
          </p>
        </div>

        {connected && (
          <div className="max-w-xl mx-auto mb-16">
            <div className="bg-blue-900/10 backdrop-blur-xl rounded-xl p-6 border border-blue-500/20 shadow-2xl transition-all duration-300 hover:border-blue-500/40">
              <div className="flex flex-col gap-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <img src="/solana-sol-logo.png" alt="SOL" className="w-6 h-6" />
                    <span className="text-lg font-medium text-blue-100">
                      {loading ? 'Loading...' : `${solBalance.toLocaleString()} SOL`}
                    </span>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={fetchBalances}
                    disabled={loading}
                    className="hover:bg-blue-500/10 transition-colors duration-300"
                  >
                    <Loader2 className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
                  </Button>
                </div>
                <div className="flex items-center gap-3">
                  <img src="/PULSR LOGO.png" alt="PULSR" className="w-6 h-6" />
                  <span className="text-lg font-medium text-purple-200">
                    {loading ? 'Loading...' : `${pulsrBalance.toLocaleString()} PULSR`}
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {!connected ? (
          <Card className="max-w-md mx-auto bg-blue-900/10 border-blue-500/20 backdrop-blur-xl transition-all duration-300 hover:border-blue-500/40">
            <CardContent className="p-8 text-center">
              <p className="text-lg text-blue-100/80 mb-4">Connect your Phantom wallet to access the GPT Vault</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {SAMPLE_GPTS.map((gpt) => (
              <Card key={gpt.id} className="bg-blue-900/10 border-blue-500/20 backdrop-blur-xl hover:border-blue-400/40 transition-all duration-300 transform hover:-translate-y-1">
                <CardHeader>
                  <div className="aspect-video relative overflow-hidden rounded-t-lg bg-gradient-to-br from-blue-900/30 to-purple-900/30">
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-4xl transform transition-transform hover:scale-110">🤖</span>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-6">
                  <CardTitle className="text-xl mb-3 bg-gradient-to-r from-white to-blue-200 bg-clip-text text-transparent">
                    {gpt.name}
                  </CardTitle>
                  <p className="text-blue-100/70 mb-6">{gpt.description}</p>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button
                        className="w-full bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 transition-all duration-300 shadow-lg hover:shadow-blue-500/25"
                        onClick={() => setSelectedGPT(gpt)}
                      >
                        Purchase Access
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="bg-black/95 border-blue-500/20 backdrop-blur-xl">
                      <DialogHeader>
                        <DialogTitle>Select Payment Method</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4 p-4">
                        <Button
                          className="w-full bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 transition-all duration-300 flex items-center justify-center gap-2"
                          onClick={() => handlePurchase(gpt, PaymentMethod.SOL)}
                          disabled={processingPayment}
                        >
                          {processingPayment ? (
                            <Loader2 className="h-4 w-4 animate-spin mr-2" />
                          ) : (
                            <img src="/solana-sol-logo.png" alt="SOL" className="w-6 h-6" />
                          )}
                          <span>{gpt.price} SOL</span>
                        </Button>
                        <Button
                          className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 transition-all duration-300 flex items-center justify-center gap-2"
                          onClick={() => handlePurchase(gpt, PaymentMethod.PULSR)}
                          disabled={processingPayment}
                        >
                          {processingPayment ? (
                            <Loader2 className="h-4 w-4 animate-spin mr-2" />
                          ) : (
                            <img src="/PULSR LOGO.png" alt="PULSR" className="w-6 h-6" />
                          )}
                          <span>100 PULSR</span>
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        <TransactionStatus
          isOpen={showTransaction}
          onClose={() => setShowTransaction(false)}
          status={transactionStatus}
          error={transactionError}
          details={transactionDetails}
        />
      </div>
    </div>
  );
};

export default HomePage;