import { Buffer } from 'buffer';

window.Buffer = Buffer;
