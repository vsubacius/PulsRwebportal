import { Connection, PublicKey, Transaction, SystemProgram, LAMPORTS_PER_SOL } from '@solana/web3.js';
import { createTransferInstruction, getAssociatedTokenAddress, TOKEN_PROGRAM_ID } from '@solana/spl-token';
import { useWallet } from '@solana/wallet-adapter-react';

// Merchant wallet address (mainnet)
// TODO: Replace with production wallet address before deployment
export const MERCHANT_WALLET = new PublicKey('9W6gc49eVTr4KJVXxszyR1ijXg9YgT8tWSjDGj9V2GdB');

// Token mints on Solana mainnet
export const PULSR_MINT = new PublicKey('7LvJrVmmY7BYPA76EzATeRerjKbsfNUxkRzEtiJ4pump');

export enum PaymentMethod {
  SOL = 'SOL',
  PULSR = 'PULSR',
}

// Your QuickNode URL
const QUICKNODE_RPC_URL = 'https://crimson-black-energy.solana-mainnet.quiknode.pro/3c287bf97f20430bfb2a4e9d2f56c9338c33b8a1';

async function createPayment(
  connection: Connection,
  amount: number,
  paymentMethod: PaymentMethod,
  fromWallet: PublicKey
): Promise<Transaction> {
  try {
    console.log(`[Payment] Creating ${paymentMethod} payment for ${amount} from ${fromWallet.toString()}`);
    console.log(`[Payment] Network: ${connection.rpcEndpoint}`);

    const { blockhash, lastValidBlockHeight } = await connection.getLatestBlockhash('confirmed');
    const transaction = new Transaction();

    switch (paymentMethod) {
      case PaymentMethod.SOL: {
        const lamports = amount * LAMPORTS_PER_SOL;
        const balance = await connection.getBalance(fromWallet, 'confirmed');

        console.log(`[Payment] Current SOL balance: ${balance / LAMPORTS_PER_SOL} SOL`);
        if (balance < lamports) {
          throw new Error(`Insufficient SOL balance. Required: ${amount} SOL, Available: ${balance / LAMPORTS_PER_SOL} SOL`);
        }

        transaction.add(
          SystemProgram.transfer({
            fromPubkey: fromWallet,
            toPubkey: MERCHANT_WALLET,
            lamports,
          })
        );
        break;
      }

      case PaymentMethod.PULSR: {
        const fromTokenAccount = await getAssociatedTokenAddress(PULSR_MINT, fromWallet);
        const toTokenAccount = await getAssociatedTokenAddress(PULSR_MINT, MERCHANT_WALLET);

        const tokenBalance = await connection.getTokenAccountBalance(fromTokenAccount);

        console.log(`[Payment] Current PULSR balance:`, tokenBalance.value.uiAmount);
        if (!tokenBalance.value.uiAmount || tokenBalance.value.uiAmount < amount) {
          throw new Error(`Insufficient PULSR balance. Required: ${amount}, Available: ${tokenBalance.value.uiAmount || 0}`);
        }

        const tokenAmount = BigInt(amount * 1e6); // Assuming 6 decimals for PULSR token
        transaction.add(createTransferInstruction(fromTokenAccount, toTokenAccount, fromWallet, tokenAmount));
        break;
      }

      default:
        throw new Error(`Unsupported payment method: ${paymentMethod}`);
    }

    transaction.recentBlockhash = blockhash;
    transaction.feePayer = fromWallet;
    transaction.lastValidBlockHeight = lastValidBlockHeight;

    return transaction;
  } catch (error: any) {
    console.error('[Payment] Error creating payment transaction:', error);
    throw new Error(`Failed to create payment transaction: ${error.message}`);
  }
}

async function fetchSolBalance(connection: Connection, walletAddress: string): Promise<number> {
  try {
    const balance = await connection.getBalance(new PublicKey(walletAddress), 'confirmed');
    return balance / LAMPORTS_PER_SOL;
  } catch (error) {
    console.error('[Wallet] Error fetching SOL balance:', error);
    throw new Error('Error fetching SOL balance');
  }
}

async function fetchPULSRBalance(connection: Connection, walletAddress: string): Promise<number> {
  try {
    const walletPubkey = new PublicKey(walletAddress);
    const tokenAccount = await getAssociatedTokenAddress(PULSR_MINT, walletPubkey);

    try {
      const balance = await connection.getTokenAccountBalance(tokenAccount);
      return balance.value.uiAmount || 0;
    } catch (error) {
      console.log('[Wallet] No PULSR token account found, returning 0');
      return 0;
    }
  } catch (error) {
    console.error('[Wallet] Error fetching PULSR balance:', error);
    throw new Error('Error fetching PULSR balance');
  }
}

export function usePayment() {
  const connection = new Connection(QUICKNODE_RPC_URL, 'confirmed');
  const { publicKey, sendTransaction } = useWallet();

  const handlePayment = async (amount: number, paymentMethod: PaymentMethod) => {
    if (!publicKey) {
      throw new Error('Wallet not connected');
    }

    const transaction = await createPayment(connection, amount, paymentMethod, publicKey);

    console.log('[Payment] Sending transaction to wallet for approval...');
    const signature = await sendTransaction(transaction, connection);
    console.log('[Payment] Transaction sent:', signature);
    return signature;
  };

  const getSolBalance = async (): Promise<number> => {
    if (!publicKey) {
      console.warn('[Wallet] Wallet not connected');
      return 0;
    }

    return await fetchSolBalance(connection, publicKey.toString());
  };

  const getPULSRBalance = async (): Promise<number> => {
    if (!publicKey) {
      console.warn('[Wallet] Wallet not connected');
      return 0;
    }

    return await fetchPULSRBalance(connection, publicKey.toString());
  };

  return { handlePayment, getSolBalance, getPULSRBalance };
}

async function checkNetwork() {
  const connection = new Connection(QUICKNODE_RPC_URL, 'confirmed');
  try {
    const version = await connection.getVersion();
    console.log('Connected to Solana Network:', version);
  } catch (error) {
    console.error('Error fetching network information:', error);
  }
}

checkNetwork();