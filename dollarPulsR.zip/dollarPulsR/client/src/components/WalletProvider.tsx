import { FC, ReactNode, useMemo } from 'react';
import { ConnectionProvider, WalletProvider } from '@solana/wallet-adapter-react';
import { WalletAdapterNetwork } from '@solana/wallet-adapter-base';
import { PhantomWalletAdapter } from '@solana/wallet-adapter-phantom';
import { WalletModalProvider } from '@solana/wallet-adapter-react-ui';
import { Commitment } from '@solana/web3.js';

// Import styles
import '@solana/wallet-adapter-react-ui/styles.css';

interface Props {
  children: ReactNode;
}

// Replace with your QuickNode RPC URL
const QUICKNODE_RPC_URL = 'https://crimson-black-energy.solana-mainnet.quiknode.pro/3c287bf97f20430bfb2a4e9d2f56c9338c33b8a1';

export const WalletContextProvider: FC<Props> = ({ children }) => {
  // Change to mainnet-beta since user's wallet is on mainnet
  const network = WalletAdapterNetwork.Mainnet;

  // Use the QuickNode URL instead of clusterApiUrl
  const endpoint = useMemo(() => {
    console.log('[Wallet] Initializing connection to network:', network);
    console.log('[Wallet] Using QuickNode RPC endpoint:', QUICKNODE_RPC_URL);
    return QUICKNODE_RPC_URL;
  }, [network]);

  // Initialize Phantom wallet adapter with proper configuration
  const wallets = useMemo(() => {
    console.log('[Wallet] Setting up wallet adapters');
    const adapter = new PhantomWalletAdapter({
      network: network,
    });

    // Add event listeners for wallet state changes
    adapter.on('connect', () => {
      console.log('[Wallet] Connected to wallet:', adapter.publicKey?.toString());
    });

    adapter.on('disconnect', () => {
      console.log('[Wallet] Disconnected from wallet');
    });

    adapter.on('error', (error) => {
      console.error('[Wallet] Adapter error:', error);
    });

    return [adapter];
  }, [network]);

  // Configure connection settings
  const config = useMemo(
    () => ({
      commitment: 'confirmed' as Commitment,
      confirmTransactionInitialTimeout: 60000, // 60 seconds
      wsEndpoint: QUICKNODE_RPC_URL.replace('https', 'wss'), // WebSocket endpoint
      preflightCommitment: 'processed' as Commitment,
      skipPreflight: false,
    }),
    []
  );

  return (
    <ConnectionProvider endpoint={endpoint} config={config}>
      <WalletProvider
        wallets={wallets}
        autoConnect={true}
        onError={(error) => {
          console.error('[Wallet] Provider error:', error);
        }}
      >
        <WalletModalProvider>
          {children}
        </WalletModalProvider>
      </WalletProvider>
    </ConnectionProvider>
  );
};

export default WalletContextProvider;
