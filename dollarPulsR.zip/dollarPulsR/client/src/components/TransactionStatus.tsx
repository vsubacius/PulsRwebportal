import { FC } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Loader2, CheckCircle2, XCircle } from "lucide-react";
import { PaymentMethod } from '@/lib/payment';

interface TransactionStatusProps {
  isOpen: boolean;
  onClose: () => void;
  status: 'preparing' | 'processing' | 'success' | 'error';
  error?: string;
  details: {
    amount: number;
    paymentMethod: PaymentMethod;
    fromWallet?: string;
    toWallet: string;
    signature?: string;
  };
}

export const TransactionStatus: FC<TransactionStatusProps> = ({
  isOpen,
  onClose,
  status,
  error,
  details
}) => {
  return (
    <Dialog open={isOpen} onOpenChange={() => status !== 'processing' && onClose()}>
      <DialogContent className="bg-black/95 border-blue-500">
        <DialogHeader>
          <DialogTitle>Transaction Status</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="flex flex-col items-center justify-center py-4">
            {status === 'preparing' && (
              <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
            )}
            {status === 'processing' && (
              <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
            )}
            {status === 'success' && (
              <CheckCircle2 className="h-8 w-8 text-green-500" />
            )}
            {status === 'error' && (
              <XCircle className="h-8 w-8 text-red-500" />
            )}
            <p className="mt-2 text-lg font-semibold">
              {status === 'preparing' && 'Preparing Transaction...'}
              {status === 'processing' && 'Processing Transaction...'}
              {status === 'success' && 'Transaction Successful!'}
              {status === 'error' && 'Transaction Failed'}
            </p>
          </div>

          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-400">Amount:</span>
              <span>{details.amount} {details.paymentMethod}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">From:</span>
              <span className="text-xs">{details.fromWallet || 'Connecting...'}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">To:</span>
              <span className="text-xs">{details.toWallet}</span>
            </div>
            {details.signature && (
              <div className="flex justify-between">
                <span className="text-gray-400">Signature:</span>
                <span className="text-xs">{details.signature}</span>
              </div>
            )}
          </div>

          {error && (
            <div className="p-3 bg-red-500/20 border border-red-500 rounded-md">
              <p className="text-sm text-red-400">{error}</p>
            </div>
          )}

          {status !== 'processing' && (
            <Button 
              onClick={onClose}
              className="w-full bg-blue-600 hover:bg-blue-500"
            >
              Close
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};
