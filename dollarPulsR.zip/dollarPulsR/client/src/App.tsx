import { Switch, Route } from "wouter";
import { WalletMultiButton } from "@solana/wallet-adapter-react-ui";
import { ConnectionProvider, WalletProvider } from "@solana/wallet-adapter-react";
import { PhantomWalletAdapter } from "@solana/wallet-adapter-phantom";
import { WalletAdapterNetwork } from "@solana/wallet-adapter-base";
import { clusterApiUrl } from "@solana/web3.js";
import { useMemo } from "react";
import { Button } from "@/components/ui/button";
import HomePage from "./pages/HomePage";
import "@solana/wallet-adapter-react-ui/styles.css";

function App() {
  const network = WalletAdapterNetwork.Mainnet;
  const endpoint = useMemo(() => clusterApiUrl(network), [network]);
  const wallets = useMemo(
    () => [
      new PhantomWalletAdapter(),
    ],
    []
  );

  return (
    <ConnectionProvider endpoint={endpoint}>
      <WalletProvider wallets={wallets} autoConnect>
        <div className="min-h-screen relative">
          {/* Background Image with overlay */}
          <div className="fixed inset-0 z-0">
            <img 
              src="/EARTH.jpg" 
              alt="Earth Background" 
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-black/70" /> {/* Dark overlay for readability */}
          </div>

          {/* Content */}
          <div className="relative z-10">
            {/* Enhanced Blue Banner with glassmorphism effect */}
            <header className="bg-blue-600/90 backdrop-blur-sm border-b border-blue-500/50 sticky top-0 z-50">
              <div className="container mx-auto px-4 py-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {/* Left side - Logo and Title with enhanced animation */}
                    <div className="flex items-center gap-2 group">
                      <img 
                        src="/Logo-pulsr.png" 
                        alt="PulsR" 
                        className="w-8 h-8 object-contain transition-transform group-hover:scale-110"
                      />
                      <h1 className="text-white font-bold text-xl bg-gradient-to-r from-white to-blue-200 bg-clip-text text-transparent">
                        PulsR GPT Vault
                      </h1>
                    </div>
                  </div>
                  {/* Right side - Navigation with enhanced buttons */}
                  <div className="flex items-center gap-4">
                    <Button 
                      variant="ghost" 
                      className="text-white hover:bg-blue-700/50 transition-all duration-300 backdrop-blur-sm"
                      onClick={() => window.open('https://dexscreener.com/solana/bkbuqnusgzbaj6xmodf595accnduy9k4vydfwxrcpxua', '_blank')}
                    >
                      DexScreener
                    </Button>
                    <Button 
                      variant="ghost" 
                      className="text-white hover:bg-blue-700/50 transition-all duration-300 backdrop-blur-sm"
                    >
                      Learn More
                    </Button>
                    <WalletMultiButton className="!bg-blue-700 hover:!bg-blue-800 !transition-all !duration-300 !shadow-lg" />
                  </div>
                </div>
              </div>
            </header>

            <Switch>
              <Route path="/" component={HomePage} />
              <Route>
                <div className="container mx-auto px-4 py-8 text-center">
                  <h1 className="text-2xl font-bold text-white">404 - Page Not Found</h1>
                </div>
              </Route>
            </Switch>
          </div>
        </div>
      </WalletProvider>
    </ConnectionProvider>
  );
}

export default App;